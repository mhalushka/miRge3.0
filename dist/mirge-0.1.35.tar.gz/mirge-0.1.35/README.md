# Project_120919

An update to Python program to perform comprehensive analysis of miRNA sequencing Data, including miRNA annotation, A-to-I analysis, novel miRNA detection, isomiR analysis and tRF detection etc.

Links
-----

* [Documentation](<https://blank.readthedocs.io/>)
* [Source code](<https://github.com/mhalushka/mirge/>)
* [Report an issue](<https://github.com/mhalushka/mirge/issues>)
* [Project page on PyPI](<https://pypi.python.org/pypi/mirge/>)

